
package answer3;


public class Answer3 {

    
    public static void main(String[] args) {
          

        double a;
        double b;
        a = 10;
        b = 20;

        System.out.println("the a+b is" + (a + b));
        System.out.println("the a-b is" + (a - b));

        System.out.println("the a*b is" + (a * b));
        System.out.println("the a/b is" + (a / b));
    }
    
}
