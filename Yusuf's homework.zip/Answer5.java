
package answer5;


public class Answer5 {

   
    public static void main(String[] args) {
        String firstName="Yusuf";
        String lastName="Dawari";
        
        String fullName= firstName+lastName;
        System.out.println(fullName);
                
       
    }
    
}
