
package answer7;


public class Answer7 {

   
    public static void main(String[] args) {
        int x, y, reminder;
        x=15;
        y=4;
        reminder=x%y;
        System.out.println("the reminder is "+reminder);
        
                
    }
    
}
