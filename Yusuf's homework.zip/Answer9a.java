package answer9a;

public class Answer9a {

    public static void main(String[] args) {
        int x = 5;
        x += 3;
        System.out.println("x after +=3" + x);
        x -= 2;
        System.out.println("x after -=2" + x);
        x *= 4;
        System.out.println("x after *=4" + x);
        x /= 3;
        System.out.println("x after /=3" + x);
        x %= 5;
        System.out.println("x after %=5" + x);

    }

}
