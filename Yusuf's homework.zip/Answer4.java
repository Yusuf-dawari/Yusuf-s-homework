
package answer4;


public class Answer4 {

    public static void main(String[] args) {
        char x='a';
        int num=100;
        System.out.println(x);
        System.out.println(num);
    }
    
}
