
package answer2;


public class Answer2 {

   
  
    public static void main(String[] args) {
        final double PI=3.14;
                System.out.println(PI);

        
    }
    
}
