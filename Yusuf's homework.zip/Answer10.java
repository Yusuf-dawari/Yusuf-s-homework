package answer10;

public class Answer10 {

    public static void main(String[] args) {
        boolean a = true;
        boolean b = false;

        boolean andresult = a && b;
        System.out.println("a&&b" + andresult);
        boolean orresult = a || b;
        System.out.println("a||b" + orresult);
        boolean notA=!a;
        boolean notB=!b;
                System.out.println("!a:"+notA);
                System.out.println("!b:"+notB);


    }

}
